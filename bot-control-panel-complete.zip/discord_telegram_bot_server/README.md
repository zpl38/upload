# 🤖 Bot Control Panel

Um sistema completo de controle remoto para bots Discord e Telegram com painel web moderno e funcionalidades avançadas de automação.

![Theme](https://img.shields.io/badge/Theme-Purple%20%26%20Black-blueviolet)
![Python](https://img.shields.io/badge/Python-3.8+-blue)
![React](https://img.shields.io/badge/React-18+-61dafb)
![Flask](https://img.shields.io/badge/Flask-2.0+-green)

## 🌟 Características

### 🎨 Interface Moderna
- **Tema Roxo/Preto**: Design moderno e profissional
- **Responsivo**: Funciona em desktop e mobile
- **Animações Suaves**: Efeitos visuais e transições
- **Dashboard Interativo**: Painel de controle completo

### 🔐 Sistema de Autenticação
- **Login Seguro**: Sistema de autenticação com hash de senhas
- **Controle de Acesso**: Níveis de usuário (admin/normal)
- **Sessões Persistentes**: Login automático
- **Gerenciamento de Usuários**: CRUD completo

### 🤖 Bots Integrados
- **Discord Bot**: Comandos personalizáveis e controle remoto
- **Telegram Bot**: Interface completa com comandos dinâmicos
- **Comandos Dinâmicos**: Adicione comandos via painel web
- **Execução Remota**: Execute código Python remotamente

### 🛠️ Funcionalidades Avançadas
- **Sistema de Informações**: Monitoramento do sistema
- **Captura de Tela**: Screenshots remotos (simulado)
- **Execução Shell**: Comandos do sistema
- **Download de Arquivos**: Baixar arquivos remotamente
- **Keylogger Simulado**: Para fins educacionais
- **Listagem de Processos**: Monitoramento de processos

## 📋 Pré-requisitos

### Sistema Operacional
- Linux (Ubuntu/Debian recomendado)
- macOS (parcialmente testado)
- Windows (com WSL recomendado)

### Software Necessário
- **Python 3.8+** com pip
- **Node.js 16+** com npm
- **Git** (para clonagem)

### Tokens Necessários
- **Discord Bot Token**: Criar em https://discord.com/developers/applications
- **Telegram Bot Token**: Criar com @BotFather no Telegram

## 🚀 Instalação Rápida

### 1. Clone o Repositório
```bash
# Se você recebeu um arquivo ZIP, extraia-o primeiro
unzip bot-control-panel.zip
cd discord_telegram_bot_server
```

### 2. Execute a Instalação Automatizada
```bash
chmod +x scripts/install.sh
./scripts/install.sh
```

### 3. Configure os Tokens
Edite o arquivo `config.env`:
```bash
nano config.env
```

Adicione seus tokens:
```env
DISCORD_BOT_TOKEN=seu_token_discord_aqui
TELEGRAM_BOT_TOKEN=seu_token_telegram_aqui
```

### 4. Inicie o Sistema
```bash
./scripts/start.sh
```

### 5. Acesse o Painel
- **URL**: http://localhost:5173
- **Usuário**: admin
- **Senha**: admin123

## 📁 Estrutura do Projeto

```
discord_telegram_bot_server/
├── backend/
│   └── bot_server/
│       ├── src/
│       │   ├── main.py              # Servidor Flask principal
│       │   ├── models/
│       │   │   └── user.py          # Modelos do banco de dados
│       │   ├── routes/
│       │   │   ├── auth.py          # Rotas de autenticação
│       │   │   ├── bot.py           # Rotas dos bots
│       │   │   └── user.py          # Rotas de usuários
│       │   └── bots/
│       │       ├── discord_bot.py   # Bot Discord
│       │       ├── telegram_bot.py  # Bot Telegram
│       │       └── example_commands.py # Comandos de exemplo
│       ├── venv/                    # Ambiente virtual Python
│       └── requirements.txt         # Dependências Python
├── frontend/
│   └── bot-panel/
│       ├── src/
│       │   ├── App.jsx             # Componente principal
│       │   ├── components/
│       │   │   ├── Login.jsx       # Tela de login
│       │   │   └── Dashboard.jsx   # Dashboard principal
│       │   └── App.css             # Estilos personalizados
│       └── package.json            # Dependências Node.js
├── scripts/
│   ├── install.sh                  # Script de instalação
│   ├── start.sh                    # Script de inicialização
│   └── stop.sh                     # Script de parada
├── logs/                           # Logs do sistema
├── config.env                      # Configurações (criar após instalação)
└── README.md                       # Este arquivo
```

## 🎮 Como Usar

### Painel Web

1. **Login**: Use admin/admin123 para primeiro acesso
2. **Dashboard**: Visualize estatísticas e status dos bots
3. **Controle de Bots**: Inicie/pare bots Discord e Telegram
4. **Gerenciamento**: Adicione usuários e configure comandos

### Bots Discord

1. **Convide o Bot**: Use o link do Discord Developer Portal
2. **Comandos Básicos**:
   - `!ping` - Verificar latência
   - `!info` - Informações do bot
   - `!sysinfo` - Informações do sistema
   - `!processes` - Listar processos
   - `!shell <comando>` - Executar comando shell

### Bots Telegram

1. **Adicione o Bot**: Procure pelo username no Telegram
2. **Comandos Básicos**:
   - `/start` - Iniciar bot
   - `/ping` - Verificar status
   - `/auth` - Autorizar usuário
   - `/sysinfo` - Informações do sistema
   - `/execute <código>` - Executar código Python

## 🔧 Configuração Avançada

### Adicionando Comandos Personalizados

1. Acesse o painel web
2. Vá para a seção "Bots"
3. Adicione um novo comando com:
   - **Nome**: Nome do comando
   - **Descrição**: Descrição do comando
   - **Código**: Código Python a ser executado
   - **Plataforma**: discord, telegram ou both

### Exemplo de Comando Personalizado

```python
# Comando para obter informações de rede
import subprocess

async def execute(ctx, *args, **kwargs):
    try:
        result = subprocess.run(['ifconfig'], capture_output=True, text=True)
        output = result.stdout[:1500]  # Limitar saída
        
        if hasattr(ctx, 'send'):  # Discord
            await ctx.send(f"```\n{output}\n```")
        else:  # Telegram
            await update.message.reply_text(f"```\n{output}\n```", parse_mode='Markdown')
    except Exception as e:
        error_msg = f"Erro: {str(e)}"
        if hasattr(ctx, 'send'):
            await ctx.send(error_msg)
        else:
            await update.message.reply_text(error_msg)
```

### Configurando Tokens

#### Discord Bot
1. Acesse https://discord.com/developers/applications
2. Crie uma nova aplicação
3. Vá para "Bot" e crie um bot
4. Copie o token e adicione ao `config.env`
5. Configure permissões necessárias

#### Telegram Bot
1. Converse com @BotFather no Telegram
2. Use `/newbot` para criar um novo bot
3. Copie o token fornecido
4. Adicione ao `config.env`

## 🛠️ Scripts Disponíveis

### Instalação
```bash
./scripts/install.sh    # Instala todas as dependências
```

### Controle do Sistema
```bash
./scripts/start.sh      # Inicia o sistema completo
./scripts/stop.sh       # Para todos os serviços
```

### Desenvolvimento
```bash
# Backend (Flask)
cd backend/bot_server
source venv/bin/activate
python src/main.py

# Frontend (React)
cd frontend/bot-panel
pnpm run dev
```

## 🔒 Segurança

### Considerações Importantes

1. **Tokens**: Nunca compartilhe tokens de bots
2. **Senhas**: Altere a senha padrão do admin
3. **Firewall**: Configure firewall para produção
4. **HTTPS**: Use HTTPS em produção
5. **Backup**: Faça backup do banco de dados

### Configurações de Produção

Para uso em produção, considere:

1. **Variáveis de Ambiente**: Use variáveis de ambiente para tokens
2. **Banco de Dados**: Migre para PostgreSQL/MySQL
3. **Proxy Reverso**: Use Nginx como proxy
4. **SSL**: Configure certificados SSL
5. **Monitoramento**: Implemente logs e monitoramento

## 🐛 Solução de Problemas

### Problemas Comuns

#### Erro de Instalação
```bash
# Limpar cache e reinstalar
rm -rf backend/bot_server/venv
rm -rf frontend/bot-panel/node_modules
./scripts/install.sh
```

#### Bots Não Iniciam
1. Verifique se os tokens estão corretos no `config.env`
2. Verifique se o bot tem permissões necessárias
3. Consulte os logs em `logs/flask.log`

#### Erro de Porta em Uso
```bash
# Parar todos os processos
./scripts/stop.sh

# Forçar liberação de portas
sudo lsof -ti:5000 | xargs kill -9
sudo lsof -ti:5173 | xargs kill -9
```

#### Problemas de Permissão
```bash
# Corrigir permissões dos scripts
chmod +x scripts/*.sh
```

### Logs e Debugging

- **Flask**: `logs/flask.log`
- **React**: `logs/react.log`
- **Console do Navegador**: F12 para debug do frontend

## 📚 API Endpoints

### Autenticação
- `POST /api/auth/login` - Fazer login
- `POST /api/auth/register` - Registrar usuário
- `POST /api/auth/logout` - Fazer logout
- `GET /api/auth/me` - Obter usuário atual

### Bots
- `GET /api/bot/status` - Status dos bots
- `POST /api/bot/start/{platform}` - Iniciar bot
- `POST /api/bot/stop/{platform}` - Parar bot
- `GET /api/bot/commands` - Listar comandos
- `POST /api/bot/commands` - Criar comando

### Usuários
- `GET /api/auth/users` - Listar usuários (admin)
- `PUT /api/auth/users/{id}` - Atualizar usuário (admin)
- `DELETE /api/auth/users/{id}` - Deletar usuário (admin)

## 🤝 Contribuição

Este projeto foi criado para fins educacionais e de demonstração. Para contribuições:

1. Fork o projeto
2. Crie uma branch para sua feature
3. Commit suas mudanças
4. Push para a branch
5. Abra um Pull Request

## ⚖️ Licença e Disclaimer

**IMPORTANTE**: Este software é fornecido apenas para fins educacionais e de pesquisa. 

### Uso Responsável
- Use apenas em sistemas que você possui ou tem autorização
- Respeite as leis locais e termos de serviço
- Não use para atividades maliciosas ou ilegais

### Limitação de Responsabilidade
Os autores não se responsabilizam pelo uso inadequado deste software.

## 📞 Suporte

Para suporte e dúvidas:

1. Consulte este README
2. Verifique os logs do sistema
3. Teste em ambiente limpo
4. Documente o problema com detalhes

---

**Desenvolvido com 💜 usando Python, React e muito café ☕**

*Bot Control Panel v1.0 - Sistema de Controle de Bots Moderno*

