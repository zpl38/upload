#!/bin/bash

# Script de Instalação Automatizada - Bot Control Panel
# Autor: Sistema Automatizado
# Versão: 1.0

echo "=========================================="
echo "  Bot Control Panel - Instalação"
echo "=========================================="
echo ""

# Cores para output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
PURPLE='\033[0;35m'
NC='\033[0m' # No Color

# Função para imprimir mensagens coloridas
print_status() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

print_success() {
    echo -e "${GREEN}[SUCESSO]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[AVISO]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERRO]${NC} $1"
}

print_header() {
    echo -e "${PURPLE}$1${NC}"
}

# Verificar se está rodando como root
if [[ $EUID -eq 0 ]]; then
   print_error "Este script não deve ser executado como root"
   exit 1
fi

# Verificar sistema operacional
if [[ "$OSTYPE" == "linux-gnu"* ]]; then
    print_status "Sistema Linux detectado"
elif [[ "$OSTYPE" == "darwin"* ]]; then
    print_status "Sistema macOS detectado"
else
    print_warning "Sistema operacional não testado: $OSTYPE"
fi

print_header "1. Verificando dependências do sistema..."

# Verificar Python
if command -v python3 &> /dev/null; then
    PYTHON_VERSION=$(python3 --version | cut -d ' ' -f 2)
    print_success "Python3 encontrado: $PYTHON_VERSION"
else
    print_error "Python3 não encontrado. Instale Python 3.8+ primeiro."
    exit 1
fi

# Verificar pip
if command -v pip3 &> /dev/null; then
    print_success "pip3 encontrado"
else
    print_error "pip3 não encontrado. Instale pip primeiro."
    exit 1
fi

# Verificar Node.js
if command -v node &> /dev/null; then
    NODE_VERSION=$(node --version)
    print_success "Node.js encontrado: $NODE_VERSION"
else
    print_error "Node.js não encontrado. Instale Node.js 16+ primeiro."
    exit 1
fi

# Verificar pnpm
if command -v pnpm &> /dev/null; then
    print_success "pnpm encontrado"
else
    print_status "Instalando pnpm..."
    npm install -g pnpm
    if [ $? -eq 0 ]; then
        print_success "pnpm instalado com sucesso"
    else
        print_error "Falha ao instalar pnpm"
        exit 1
    fi
fi

print_header "2. Configurando ambiente Python (Backend)..."

# Navegar para o diretório do backend
cd backend/bot_server

# Criar ambiente virtual se não existir
if [ ! -d "venv" ]; then
    print_status "Criando ambiente virtual Python..."
    python3 -m venv venv
    if [ $? -eq 0 ]; then
        print_success "Ambiente virtual criado"
    else
        print_error "Falha ao criar ambiente virtual"
        exit 1
    fi
else
    print_status "Ambiente virtual já existe"
fi

# Ativar ambiente virtual e instalar dependências
print_status "Instalando dependências Python..."
source venv/bin/activate

# Atualizar requirements.txt
pip freeze > requirements.txt

# Instalar dependências
pip install -r requirements.txt
if [ $? -eq 0 ]; then
    print_success "Dependências Python instaladas"
else
    print_error "Falha ao instalar dependências Python"
    exit 1
fi

# Voltar ao diretório raiz
cd ../..

print_header "3. Configurando ambiente Node.js (Frontend)..."

# Navegar para o diretório do frontend
cd frontend/bot-panel

# Instalar dependências do frontend
print_status "Instalando dependências Node.js..."
pnpm install
if [ $? -eq 0 ]; then
    print_success "Dependências Node.js instaladas"
else
    print_error "Falha ao instalar dependências Node.js"
    exit 1
fi

# Voltar ao diretório raiz
cd ../..

print_header "4. Configurando banco de dados..."

# Inicializar banco de dados
print_status "Inicializando banco de dados..."
cd backend/bot_server
source venv/bin/activate
python populate_commands.py
if [ $? -eq 0 ]; then
    print_success "Banco de dados configurado"
else
    print_warning "Aviso: Banco pode já estar configurado"
fi

cd ../..

print_header "5. Criando arquivos de configuração..."

# Criar arquivo de configuração para tokens
if [ ! -f "config.env" ]; then
    cat > config.env << EOF
# Configuração dos Bots - Bot Control Panel
# Edite este arquivo com seus tokens reais

# Token do Bot Discord
DISCORD_BOT_TOKEN=seu_token_discord_aqui

# Token do Bot Telegram
TELEGRAM_BOT_TOKEN=seu_token_telegram_aqui

# Configurações do Flask
FLASK_SECRET_KEY=sua_chave_secreta_aqui
FLASK_DEBUG=true

# Configurações do Banco
DATABASE_URL=sqlite:///src/database/app.db
EOF
    print_success "Arquivo config.env criado"
    print_warning "IMPORTANTE: Edite o arquivo config.env com seus tokens reais!"
else
    print_status "Arquivo config.env já existe"
fi

print_header "6. Configurando permissões..."

# Tornar scripts executáveis
chmod +x scripts/*.sh
print_success "Permissões configuradas"

print_header "=========================================="
print_success "INSTALAÇÃO CONCLUÍDA COM SUCESSO!"
print_header "=========================================="

echo ""
print_status "Próximos passos:"
echo "1. Edite o arquivo 'config.env' com seus tokens de bot"
echo "2. Execute './scripts/start.sh' para iniciar o sistema"
echo "3. Acesse http://localhost:5173 no navegador"
echo "4. Use as credenciais: admin / admin123"
echo ""
print_warning "Leia o arquivo README.md para instruções detalhadas"
echo ""

