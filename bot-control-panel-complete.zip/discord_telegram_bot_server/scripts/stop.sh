#!/bin/bash

# Script de Parada - Bot Control Panel
# Autor: Sistema Automatizado
# Versão: 1.0

echo "=========================================="
echo "  Bot Control Panel - Parada do Sistema"
echo "=========================================="
echo ""

# Cores para output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
PURPLE='\033[0;35m'
NC='\033[0m' # No Color

# Função para imprimir mensagens coloridas
print_status() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

print_success() {
    echo -e "${GREEN}[SUCESSO]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[AVISO]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERRO]${NC} $1"
}

print_header() {
    echo -e "${PURPLE}$1${NC}"
}

print_header "1. Parando serviços..."

# Parar Flask
if [ -f "logs/flask.pid" ]; then
    FLASK_PID=$(cat logs/flask.pid)
    if kill -0 $FLASK_PID 2>/dev/null; then
        print_status "Parando servidor Flask (PID: $FLASK_PID)..."
        kill $FLASK_PID
        sleep 2
        if kill -0 $FLASK_PID 2>/dev/null; then
            print_warning "Forçando parada do Flask..."
            kill -9 $FLASK_PID
        fi
        print_success "Servidor Flask parado"
    else
        print_warning "Servidor Flask já estava parado"
    fi
    rm -f logs/flask.pid
else
    print_warning "PID do Flask não encontrado"
fi

# Parar React
if [ -f "logs/react.pid" ]; then
    REACT_PID=$(cat logs/react.pid)
    if kill -0 $REACT_PID 2>/dev/null; then
        print_status "Parando servidor React (PID: $REACT_PID)..."
        kill $REACT_PID
        sleep 2
        if kill -0 $REACT_PID 2>/dev/null; then
            print_warning "Forçando parada do React..."
            kill -9 $REACT_PID
        fi
        print_success "Servidor React parado"
    else
        print_warning "Servidor React já estava parado"
    fi
    rm -f logs/react.pid
else
    print_warning "PID do React não encontrado"
fi

print_header "2. Limpando processos relacionados..."

# Matar processos Flask restantes
FLASK_PROCS=$(pgrep -f "python.*main.py")
if [ ! -z "$FLASK_PROCS" ]; then
    print_status "Parando processos Flask restantes..."
    echo $FLASK_PROCS | xargs kill 2>/dev/null
fi

# Matar processos Node/Vite restantes
NODE_PROCS=$(pgrep -f "node.*vite")
if [ ! -z "$NODE_PROCS" ]; then
    print_status "Parando processos Node/Vite restantes..."
    echo $NODE_PROCS | xargs kill 2>/dev/null
fi

print_header "3. Parando bots (se estiverem rodando)..."

# Parar bots Discord/Telegram se estiverem rodando
BOT_PROCS=$(pgrep -f "python.*bot.py")
if [ ! -z "$BOT_PROCS" ]; then
    print_status "Parando bots..."
    echo $BOT_PROCS | xargs kill 2>/dev/null
    print_success "Bots parados"
fi

print_header "4. Verificando portas..."

# Verificar se as portas foram liberadas
sleep 2

if lsof -Pi :5000 -sTCP:LISTEN -t >/dev/null; then
    print_warning "Porta 5000 ainda está em uso"
    PROC_5000=$(lsof -Pi :5000 -sTCP:LISTEN -t)
    print_status "Forçando liberação da porta 5000..."
    kill -9 $PROC_5000 2>/dev/null
else
    print_success "Porta 5000 liberada"
fi

if lsof -Pi :5173 -sTCP:LISTEN -t >/dev/null; then
    print_warning "Porta 5173 ainda está em uso"
    PROC_5173=$(lsof -Pi :5173 -sTCP:LISTEN -t)
    print_status "Forçando liberação da porta 5173..."
    kill -9 $PROC_5173 2>/dev/null
else
    print_success "Porta 5173 liberada"
fi

print_header "=========================================="
print_success "SISTEMA PARADO COM SUCESSO!"
print_header "=========================================="

echo ""
print_status "Todos os serviços foram parados:"
echo "• Servidor Flask (Backend)"
echo "• Servidor React (Frontend)"
echo "• Bots Discord/Telegram"
echo ""
print_status "Para reiniciar o sistema:"
echo "• Execute: ./scripts/start.sh"
echo ""

