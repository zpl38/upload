#!/bin/bash

# Script de Inicialização - Bot Control Panel
# Autor: Sistema Automatizado
# Versão: 1.0

echo "=========================================="
echo "  Bot Control Panel - Inicialização"
echo "=========================================="
echo ""

# Cores para output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
PURPLE='\033[0;35m'
NC='\033[0m' # No Color

# Função para imprimir mensagens coloridas
print_status() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

print_success() {
    echo -e "${GREEN}[SUCESSO]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[AVISO]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERRO]${NC} $1"
}

print_header() {
    echo -e "${PURPLE}$1${NC}"
}

# Verificar se os diretórios existem
if [ ! -d "backend/bot_server" ]; then
    print_error "Diretório backend/bot_server não encontrado"
    exit 1
fi

if [ ! -d "frontend/bot-panel" ]; then
    print_error "Diretório frontend/bot-panel não encontrado"
    exit 1
fi

# Criar diretório para logs
mkdir -p logs

print_header "1. Iniciando Backend (Flask)..."

# Iniciar servidor Flask em background
cd backend/bot_server
source venv/bin/activate

print_status "Iniciando servidor Flask na porta 5000..."
nohup python src/main.py > ../../logs/flask.log 2>&1 &
FLASK_PID=$!
echo $FLASK_PID > ../../logs/flask.pid

# Aguardar um pouco para o Flask inicializar
sleep 3

# Verificar se o Flask está rodando
if kill -0 $FLASK_PID 2>/dev/null; then
    print_success "Servidor Flask iniciado (PID: $FLASK_PID)"
else
    print_error "Falha ao iniciar servidor Flask"
    exit 1
fi

cd ../..

print_header "2. Iniciando Frontend (React)..."

# Iniciar servidor React em background
cd frontend/bot-panel

print_status "Iniciando servidor React na porta 5173..."
nohup pnpm run dev --host > ../../logs/react.log 2>&1 &
REACT_PID=$!
echo $REACT_PID > ../../logs/react.pid

# Aguardar um pouco para o React inicializar
sleep 5

# Verificar se o React está rodando
if kill -0 $REACT_PID 2>/dev/null; then
    print_success "Servidor React iniciado (PID: $REACT_PID)"
else
    print_error "Falha ao iniciar servidor React"
    exit 1
fi

cd ../..

print_header "3. Verificando serviços..."

# Verificar se as portas estão sendo usadas
if lsof -Pi :5000 -sTCP:LISTEN -t >/dev/null; then
    print_success "Flask rodando na porta 5000"
else
    print_warning "Flask pode não estar acessível na porta 5000"
fi

if lsof -Pi :5173 -sTCP:LISTEN -t >/dev/null; then
    print_success "React rodando na porta 5173"
else
    print_warning "React pode não estar acessível na porta 5173"
fi

print_header "=========================================="
print_success "SISTEMA INICIADO COM SUCESSO!"
print_header "=========================================="

echo ""
print_status "Informações do sistema:"
echo "• Frontend (React): http://localhost:5173"
echo "• Backend (Flask): http://localhost:5000"
echo "• Logs: ./logs/"
echo ""
print_status "Credenciais padrão:"
echo "• Usuário: admin"
echo "• Senha: admin123"
echo ""
print_status "Para parar o sistema:"
echo "• Execute: ./scripts/stop.sh"
echo ""
print_warning "Mantenha este terminal aberto ou use 'nohup' para execução em background"

# Aguardar entrada do usuário para manter o script ativo
echo ""
read -p "Pressione ENTER para continuar monitorando ou Ctrl+C para sair..."

# Loop de monitoramento
while true; do
    sleep 30
    
    # Verificar se os processos ainda estão rodando
    if ! kill -0 $FLASK_PID 2>/dev/null; then
        print_error "Servidor Flask parou inesperadamente"
        break
    fi
    
    if ! kill -0 $REACT_PID 2>/dev/null; then
        print_error "Servidor React parou inesperadamente"
        break
    fi
    
    print_status "Sistema funcionando normalmente..."
done

