import logging
import sys
import os
import sqlite3
import asyncio
from telegram import Update, BotCommand
from telegram.ext import Application, CommandHandler, MessageHandler, filters, ContextTypes
from telegram.constants import ParseMode

# Configurar logging
logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO
)
logger = logging.getLogger(__name__)

# Adicionar o diretório pai ao path para importar os modelos
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(__file__))))

class TelegramBot:
    def __init__(self, token):
        self.token = token
        self.db_path = os.path.join(os.path.dirname(__file__), '..', 'database', 'app.db')
        self.application = Application.builder().token(token).build()
        self.authorized_users = set()  # IDs de usuários autorizados
        
    async def start_command(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Comando /start"""
        user = update.effective_user
        
        welcome_text = f"""
🤖 *Bot de Controle Remoto*

Olá {user.first_name}! 

Este bot permite controle remoto através do painel web.

Comandos disponíveis:
/start - Mostrar esta mensagem
/info - Informações do bot
/ping - Verificar latência
/auth - Autorizar usuário (apenas admins)
/reload - Recarregar comandos personalizados

Para mais comandos, use /help
        """
        
        await update.message.reply_text(
            welcome_text,
            parse_mode=ParseMode.MARKDOWN
        )
    
    async def ping_command(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Comando /ping"""
        await update.message.reply_text("🏓 Pong! Bot está online!")
    
    async def info_command(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Comando /info"""
        info_text = f"""
📊 *Informações do Bot*

🆔 Bot ID: {context.bot.id}
👤 Nome: {context.bot.first_name}
📝 Username: @{context.bot.username}

🔧 Status: Online
⚡ Comandos carregados: {len(self.application.handlers[0])}
        """
        
        await update.message.reply_text(
            info_text,
            parse_mode=ParseMode.MARKDOWN
        )
    
    async def auth_command(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Comando /auth - autorizar usuário"""
        user_id = update.effective_user.id
        
        # Por simplicidade, qualquer um pode se autorizar inicialmente
        # Em produção, isso deveria ser mais restritivo
        self.authorized_users.add(user_id)
        
        await update.message.reply_text(
            "✅ Usuário autorizado com sucesso!",
            parse_mode=ParseMode.MARKDOWN
        )
    
    async def reload_command(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Comando /reload - recarregar comandos personalizados"""
        user_id = update.effective_user.id
        
        if user_id not in self.authorized_users:
            await update.message.reply_text("❌ Acesso negado. Use /auth primeiro.")
            return
        
        try:
            await self.load_custom_commands()
            await update.message.reply_text("✅ Comandos recarregados com sucesso!")
        except Exception as e:
            await update.message.reply_text(f"❌ Erro ao recarregar comandos: {str(e)}")
    
    async def execute_command(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Comando /execute - executar código Python"""
        user_id = update.effective_user.id
        
        if user_id not in self.authorized_users:
            await update.message.reply_text("❌ Acesso negado. Use /auth primeiro.")
            return
        
        if not context.args:
            await update.message.reply_text("❌ Forneça o código a ser executado.")
            return
        
        code = ' '.join(context.args)
        
        try:
            # Namespace seguro
            namespace = {
                'update': update,
                'context': context,
                'bot': context.bot,
                'user': update.effective_user,
                'chat': update.effective_chat
            }
            
            # Executar código
            exec(code, namespace)
            
            await update.message.reply_text("✅ Código executado com sucesso!")
            
        except Exception as e:
            await update.message.reply_text(f"❌ Erro na execução: {str(e)}")
    
    async def load_custom_commands(self):
        """Carregar comandos personalizados do banco de dados"""
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            cursor.execute("""
                SELECT command_name, command_description, command_code 
                FROM bot_command 
                WHERE (platform = 'telegram' OR platform = 'both') AND is_active = 1
            """)
            
            commands_data = cursor.fetchall()
            conn.close()
            
            for cmd_name, cmd_desc, cmd_code in commands_data:
                await self.create_dynamic_command(cmd_name, cmd_desc, cmd_code)
                
        except Exception as e:
            logger.error(f"Erro ao carregar comandos personalizados: {e}")
    
    async def create_dynamic_command(self, name, description, code):
        """Criar comando dinâmico a partir do código"""
        try:
            # Compilar o código
            compiled_code = compile(code, f"<command_{name}>", "exec")
            
            # Criar função wrapper
            async def command_wrapper(update: Update, context: ContextTypes.DEFAULT_TYPE):
                # Namespace para execução segura do código
                namespace = {
                    'update': update,
                    'context': context,
                    'bot': context.bot,
                    'user': update.effective_user,
                    'chat': update.effective_chat,
                    'logger': logger
                }
                
                try:
                    exec(compiled_code, namespace)
                    
                    # Se existe uma função 'execute', chamá-la
                    if 'execute' in namespace and callable(namespace['execute']):
                        if asyncio.iscoroutinefunction(namespace['execute']):
                            await namespace['execute'](update, context)
                        else:
                            namespace['execute'](update, context)
                            
                except Exception as e:
                    await update.message.reply_text(f"❌ Erro ao executar comando: {str(e)}")
                    logger.error(f"Erro no comando {name}: {e}")
            
            # Registrar o comando
            handler = CommandHandler(name, command_wrapper)
            self.application.add_handler(handler)
            
            logger.info(f"Comando '{name}' carregado com sucesso")
            
        except Exception as e:
            logger.error(f"Erro ao criar comando '{name}': {e}")
    
    async def handle_message(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Processar mensagens não-comando"""
        user = update.effective_user
        message = update.message.text
        
        # Log de mensagens
        logger.info(f"Mensagem de {user.first_name} ({user.id}): {message}")
        
        # Resposta automática para mensagens não-comando
        if not message.startswith('/'):
            await update.message.reply_text(
                "👋 Olá! Use /start para ver os comandos disponíveis."
            )
    
    async def error_handler(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Tratar erros"""
        logger.error(f"Erro: {context.error}")
        
        if update and update.message:
            await update.message.reply_text(
                "❌ Ocorreu um erro interno. Tente novamente."
            )
    
    async def setup_bot(self):
        """Configurar o bot"""
        # Comandos básicos
        self.application.add_handler(CommandHandler("start", self.start_command))
        self.application.add_handler(CommandHandler("ping", self.ping_command))
        self.application.add_handler(CommandHandler("info", self.info_command))
        self.application.add_handler(CommandHandler("auth", self.auth_command))
        self.application.add_handler(CommandHandler("reload", self.reload_command))
        self.application.add_handler(CommandHandler("execute", self.execute_command))
        
        # Handler para mensagens não-comando
        self.application.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, self.handle_message))
        
        # Handler de erros
        self.application.add_error_handler(self.error_handler)
        
        # Carregar comandos personalizados
        await self.load_custom_commands()
        
        # Configurar menu de comandos
        commands = [
            BotCommand("start", "Iniciar o bot"),
            BotCommand("info", "Informações do bot"),
            BotCommand("ping", "Verificar status"),
            BotCommand("auth", "Autorizar usuário"),
            BotCommand("reload", "Recarregar comandos"),
            BotCommand("execute", "Executar código")
        ]
        
        await self.application.bot.set_my_commands(commands)
        
        logger.info("Bot Telegram configurado com sucesso!")
    
    async def run(self):
        """Executar o bot"""
        await self.setup_bot()
        
        # Iniciar o bot
        await self.application.initialize()
        await self.application.start()
        await self.application.updater.start_polling()
        
        logger.info("Bot Telegram iniciado!")
        
        # Manter o bot rodando
        try:
            await asyncio.Event().wait()
        except KeyboardInterrupt:
            logger.info("Parando bot...")
        finally:
            await self.application.updater.stop()
            await self.application.stop()
            await self.application.shutdown()

def main():
    if len(sys.argv) != 2:
        print("Uso: python telegram_bot.py <TOKEN>")
        sys.exit(1)
        
    token = sys.argv[1]
    
    bot = TelegramBot(token)
    
    try:
        asyncio.run(bot.run())
    except Exception as e:
        logger.error(f"Erro ao iniciar bot Telegram: {e}")

if __name__ == "__main__":
    main()

