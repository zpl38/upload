import discord
from discord.ext import commands
import sys
import os
import sqlite3
import asyncio
import logging

# Configurar logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Adicionar o diretório pai ao path para importar os modelos
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(__file__))))

class DiscordBot(commands.Bot):
    def __init__(self, token):
        intents = discord.Intents.default()
        intents.message_content = True
        intents.guilds = True
        intents.members = True
        
        super().__init__(
            command_prefix='!',
            intents=intents,
            help_command=None
        )
        
        self.token = token
        self.db_path = os.path.join(os.path.dirname(__file__), '..', 'database', 'app.db')
        
    async def setup_hook(self):
        """Configuração inicial do bot"""
        logger.info("Bot Discord iniciando...")
        await self.load_custom_commands()
        
    async def on_ready(self):
        """Evento chamado quando o bot está pronto"""
        logger.info(f'{self.user} conectou ao Discord!')
        logger.info(f'Bot está em {len(self.guilds)} servidores')
        
        # Definir status
        await self.change_presence(
            activity=discord.Activity(
                type=discord.ActivityType.watching,
                name="o painel de controle"
            )
        )
        
    async def on_message(self, message):
        """Processar mensagens"""
        if message.author == self.user:
            return
            
        # Log de mensagens (opcional)
        logger.info(f"Mensagem de {message.author}: {message.content}")
        
        await self.process_commands(message)
        
    async def load_custom_commands(self):
        """Carregar comandos personalizados do banco de dados"""
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            cursor.execute("""
                SELECT command_name, command_description, command_code 
                FROM bot_command 
                WHERE (platform = 'discord' OR platform = 'both') AND is_active = 1
            """)
            
            commands_data = cursor.fetchall()
            conn.close()
            
            for cmd_name, cmd_desc, cmd_code in commands_data:
                await self.create_dynamic_command(cmd_name, cmd_desc, cmd_code)
                
        except Exception as e:
            logger.error(f"Erro ao carregar comandos personalizados: {e}")
            
    async def create_dynamic_command(self, name, description, code):
        """Criar comando dinâmico a partir do código"""
        try:
            # Namespace para execução segura do código
            namespace = {
                'discord': discord,
                'commands': commands,
                'ctx': None,  # Será definido na execução
                'bot': self,
                'logger': logger
            }
            
            # Compilar o código
            compiled_code = compile(code, f"<command_{name}>", "exec")
            
            # Criar função wrapper
            async def command_wrapper(ctx, *args, **kwargs):
                namespace['ctx'] = ctx
                namespace['args'] = args
                namespace['kwargs'] = kwargs
                
                try:
                    exec(compiled_code, namespace)
                    
                    # Se existe uma função 'execute', chamá-la
                    if 'execute' in namespace and callable(namespace['execute']):
                        if asyncio.iscoroutinefunction(namespace['execute']):
                            await namespace['execute'](ctx, *args, **kwargs)
                        else:
                            namespace['execute'](ctx, *args, **kwargs)
                            
                except Exception as e:
                    await ctx.send(f"Erro ao executar comando: {str(e)}")
                    logger.error(f"Erro no comando {name}: {e}")
            
            # Registrar o comando
            command = commands.Command(
                command_wrapper,
                name=name,
                help=description or f"Comando personalizado: {name}"
            )
            
            self.add_command(command)
            logger.info(f"Comando '{name}' carregado com sucesso")
            
        except Exception as e:
            logger.error(f"Erro ao criar comando '{name}': {e}")

# Comandos básicos integrados
@commands.command(name='ping')
async def ping_command(ctx):
    """Verificar latência do bot"""
    latency = round(ctx.bot.latency * 1000)
    await ctx.send(f'🏓 Pong! Latência: {latency}ms')

@commands.command(name='info')
async def info_command(ctx):
    """Informações sobre o bot"""
    embed = discord.Embed(
        title="Informações do Bot",
        description="Bot de controle remoto com painel web",
        color=0x7B2CBF
    )
    
    embed.add_field(
        name="Servidores",
        value=len(ctx.bot.guilds),
        inline=True
    )
    
    embed.add_field(
        name="Usuários",
        value=len(set(ctx.bot.get_all_members())),
        inline=True
    )
    
    embed.add_field(
        name="Comandos",
        value=len(ctx.bot.commands),
        inline=True
    )
    
    await ctx.send(embed=embed)

@commands.command(name='reload')
@commands.has_permissions(administrator=True)
async def reload_commands(ctx):
    """Recarregar comandos personalizados (apenas admins)"""
    try:
        # Remover comandos personalizados existentes
        commands_to_remove = []
        for cmd in ctx.bot.commands:
            if cmd.name not in ['ping', 'info', 'reload', 'help']:
                commands_to_remove.append(cmd.name)
        
        for cmd_name in commands_to_remove:
            ctx.bot.remove_command(cmd_name)
        
        # Recarregar comandos
        await ctx.bot.load_custom_commands()
        
        await ctx.send("✅ Comandos recarregados com sucesso!")
        
    except Exception as e:
        await ctx.send(f"❌ Erro ao recarregar comandos: {str(e)}")

@commands.command(name='execute')
@commands.has_permissions(administrator=True)
async def execute_code(ctx, *, code):
    """Executar código Python (apenas admins)"""
    try:
        # Namespace seguro
        namespace = {
            'discord': discord,
            'ctx': ctx,
            'bot': ctx.bot,
            'guild': ctx.guild,
            'channel': ctx.channel,
            'author': ctx.author
        }
        
        # Executar código
        exec(code, namespace)
        
        await ctx.send("✅ Código executado com sucesso!")
        
    except Exception as e:
        await ctx.send(f"❌ Erro na execução: {str(e)}")

def main():
    if len(sys.argv) != 2:
        print("Uso: python discord_bot.py <TOKEN>")
        sys.exit(1)
        
    token = sys.argv[1]
    
    bot = DiscordBot(token)
    
    # Adicionar comandos básicos
    bot.add_command(ping_command)
    bot.add_command(info_command)
    bot.add_command(reload_commands)
    bot.add_command(execute_code)
    
    try:
        bot.run(token)
    except discord.LoginFailure:
        logger.error("Token do Discord inválido!")
    except Exception as e:
        logger.error(f"Erro ao iniciar bot Discord: {e}")

if __name__ == "__main__":
    main()

