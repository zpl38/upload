"""
Comandos de exemplo para os bots Discord e Telegram
Estes comandos podem ser adicionados através do painel web
"""

# Comando de informações do sistema
SYSTEM_INFO_COMMAND = """
import platform
import psutil
import datetime

async def execute(ctx, *args, **kwargs):
    try:
        # Informações do sistema
        system_info = {
            'Sistema': platform.system(),
            'Versão': platform.version(),
            'Arquitetura': platform.architecture()[0],
            'Processador': platform.processor(),
            'Hostname': platform.node(),
            'CPU %': psutil.cpu_percent(interval=1),
            'Memória %': psutil.virtual_memory().percent,
            'Disco %': psutil.disk_usage('/').percent,
            'Uptime': str(datetime.datetime.now() - datetime.datetime.fromtimestamp(psutil.boot_time()))
        }
        
        info_text = "🖥️ **Informações do Sistema**\\n\\n"
        for key, value in system_info.items():
            info_text += f"**{key}:** {value}\\n"
        
        if hasattr(ctx, 'send'):  # Discord
            await ctx.send(info_text)
        else:  # Telegram
            await update.message.reply_text(info_text, parse_mode='Markdown')
            
    except Exception as e:
        error_msg = f"❌ Erro ao obter informações: {str(e)}"
        if hasattr(ctx, 'send'):
            await ctx.send(error_msg)
        else:
            await update.message.reply_text(error_msg)
"""

# Comando de screenshot (simulado)
SCREENSHOT_COMMAND = """
import os
import datetime

async def execute(ctx, *args, **kwargs):
    try:
        # Simular captura de tela (em um ambiente real, usaria bibliotecas como PIL/Pillow)
        timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f"screenshot_{timestamp}.png"
        
        # Criar arquivo de exemplo
        with open(f"/tmp/{filename}", "w") as f:
            f.write("Screenshot simulado - " + str(datetime.datetime.now()))
        
        success_msg = f"📸 Screenshot capturado: {filename}"
        
        if hasattr(ctx, 'send'):  # Discord
            await ctx.send(success_msg)
        else:  # Telegram
            await update.message.reply_text(success_msg)
            
    except Exception as e:
        error_msg = f"❌ Erro ao capturar screenshot: {str(e)}"
        if hasattr(ctx, 'send'):
            await ctx.send(error_msg)
        else:
            await update.message.reply_text(error_msg)
"""

# Comando de listagem de processos
PROCESS_LIST_COMMAND = """
import psutil

async def execute(ctx, *args, **kwargs):
    try:
        processes = []
        for proc in psutil.process_iter(['pid', 'name', 'cpu_percent', 'memory_percent']):
            try:
                processes.append(proc.info)
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                pass
        
        # Ordenar por uso de CPU
        processes.sort(key=lambda x: x['cpu_percent'] or 0, reverse=True)
        
        # Pegar os top 10
        top_processes = processes[:10]
        
        process_text = "🔄 **Top 10 Processos (CPU)**\\n\\n"
        for proc in top_processes:
            process_text += f"**PID:** {proc['pid']} | **Nome:** {proc['name']} | **CPU:** {proc['cpu_percent']:.1f}%\\n"
        
        if hasattr(ctx, 'send'):  # Discord
            await ctx.send(process_text)
        else:  # Telegram
            await update.message.reply_text(process_text, parse_mode='Markdown')
            
    except Exception as e:
        error_msg = f"❌ Erro ao listar processos: {str(e)}"
        if hasattr(ctx, 'send'):
            await ctx.send(error_msg)
        else:
            await update.message.reply_text(error_msg)
"""

# Comando de execução de shell
SHELL_COMMAND = """
import subprocess
import asyncio

async def execute(ctx, *args, **kwargs):
    try:
        if not args:
            error_msg = "❌ Forneça um comando para executar. Exemplo: !shell ls -la"
            if hasattr(ctx, 'send'):
                await ctx.send(error_msg)
            else:
                await update.message.reply_text(error_msg)
            return
        
        command = ' '.join(args)
        
        # Executar comando (com timeout de segurança)
        result = subprocess.run(
            command,
            shell=True,
            capture_output=True,
            text=True,
            timeout=30
        )
        
        output = result.stdout if result.stdout else result.stderr
        
        if len(output) > 1900:  # Limite para Discord/Telegram
            output = output[:1900] + "\\n... (saída truncada)"
        
        response = f"🖥️ **Comando:** `{command}`\\n\\n**Saída:**\\n```\\n{output}\\n```"
        
        if hasattr(ctx, 'send'):  # Discord
            await ctx.send(response)
        else:  # Telegram
            await update.message.reply_text(response, parse_mode='Markdown')
            
    except subprocess.TimeoutExpired:
        error_msg = "⏰ Comando expirou (timeout de 30s)"
        if hasattr(ctx, 'send'):
            await ctx.send(error_msg)
        else:
            await update.message.reply_text(error_msg)
    except Exception as e:
        error_msg = f"❌ Erro ao executar comando: {str(e)}"
        if hasattr(ctx, 'send'):
            await ctx.send(error_msg)
        else:
            await update.message.reply_text(error_msg)
"""

# Comando de download de arquivo
DOWNLOAD_COMMAND = """
import requests
import os
from urllib.parse import urlparse

async def execute(ctx, *args, **kwargs):
    try:
        if not args:
            error_msg = "❌ Forneça uma URL para download. Exemplo: !download https://exemplo.com/arquivo.txt"
            if hasattr(ctx, 'send'):
                await ctx.send(error_msg)
            else:
                await update.message.reply_text(error_msg)
            return
        
        url = args[0]
        
        # Fazer download
        response = requests.get(url, timeout=30)
        response.raise_for_status()
        
        # Obter nome do arquivo
        parsed_url = urlparse(url)
        filename = os.path.basename(parsed_url.path) or "downloaded_file"
        
        # Salvar arquivo
        filepath = f"/tmp/{filename}"
        with open(filepath, 'wb') as f:
            f.write(response.content)
        
        file_size = os.path.getsize(filepath)
        success_msg = f"📥 **Download concluído!**\\n**Arquivo:** {filename}\\n**Tamanho:** {file_size} bytes\\n**Local:** {filepath}"
        
        if hasattr(ctx, 'send'):  # Discord
            await ctx.send(success_msg)
        else:  # Telegram
            await update.message.reply_text(success_msg, parse_mode='Markdown')
            
    except Exception as e:
        error_msg = f"❌ Erro no download: {str(e)}"
        if hasattr(ctx, 'send'):
            await ctx.send(error_msg)
        else:
            await update.message.reply_text(error_msg)
"""

# Comando de keylogger simulado (para fins educacionais)
KEYLOGGER_COMMAND = """
import datetime
import os

async def execute(ctx, *args, **kwargs):
    try:
        # Simular keylogger (em ambiente real, seria muito mais complexo)
        log_file = "/tmp/keylog_simulation.txt"
        
        if args and args[0] == "start":
            with open(log_file, "w") as f:
                f.write(f"Keylogger simulado iniciado em: {datetime.datetime.now()}\\n")
            
            success_msg = "🔑 Keylogger simulado iniciado!"
            
        elif args and args[0] == "stop":
            if os.path.exists(log_file):
                with open(log_file, "a") as f:
                    f.write(f"Keylogger simulado parado em: {datetime.datetime.now()}\\n")
                
                success_msg = "🛑 Keylogger simulado parado!"
            else:
                success_msg = "❌ Keylogger não estava rodando"
                
        elif args and args[0] == "dump":
            if os.path.exists(log_file):
                with open(log_file, "r") as f:
                    content = f.read()
                
                success_msg = f"📋 **Log do Keylogger:**\\n```\\n{content}\\n```"
            else:
                success_msg = "❌ Nenhum log encontrado"
        else:
            success_msg = "🔑 **Keylogger Simulado**\\nComandos: start, stop, dump"
        
        if hasattr(ctx, 'send'):  # Discord
            await ctx.send(success_msg)
        else:  # Telegram
            await update.message.reply_text(success_msg, parse_mode='Markdown')
            
    except Exception as e:
        error_msg = f"❌ Erro no keylogger: {str(e)}"
        if hasattr(ctx, 'send'):
            await ctx.send(error_msg)
        else:
            await update.message.reply_text(error_msg)
"""

# Dicionário com todos os comandos de exemplo
EXAMPLE_COMMANDS = {
    "sysinfo": {
        "name": "sysinfo",
        "description": "Obter informações do sistema",
        "code": SYSTEM_INFO_COMMAND,
        "platform": "both"
    },
    "screenshot": {
        "name": "screenshot", 
        "description": "Capturar screenshot da tela",
        "code": SCREENSHOT_COMMAND,
        "platform": "both"
    },
    "processes": {
        "name": "processes",
        "description": "Listar processos em execução",
        "code": PROCESS_LIST_COMMAND,
        "platform": "both"
    },
    "shell": {
        "name": "shell",
        "description": "Executar comando shell",
        "code": SHELL_COMMAND,
        "platform": "both"
    },
    "download": {
        "name": "download",
        "description": "Fazer download de arquivo",
        "code": DOWNLOAD_COMMAND,
        "platform": "both"
    },
    "keylogger": {
        "name": "keylogger",
        "description": "Keylogger simulado (educacional)",
        "code": KEYLOGGER_COMMAND,
        "platform": "both"
    }
}

