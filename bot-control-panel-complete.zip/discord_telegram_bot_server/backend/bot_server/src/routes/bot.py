from flask import Blueprint, request, jsonify
from flask_login import login_required, current_user
from src.models.user import db, BotConfig, BotCommand
import subprocess
import os
import threading
import signal

bot_bp = Blueprint('bot', __name__)

# Dicionário para armazenar processos dos bots
bot_processes = {}

@bot_bp.route('/configs', methods=['GET'])
@login_required
def get_bot_configs():
    if not current_user.is_admin:
        return jsonify({'error': 'Acesso negado'}), 403
        
    configs = BotConfig.query.all()
    return jsonify({'configs': [config.to_dict() for config in configs]}), 200

@bot_bp.route('/configs', methods=['POST'])
@login_required
def create_bot_config():
    if not current_user.is_admin:
        return jsonify({'error': 'Acesso negado'}), 403
        
    try:
        data = request.get_json()
        
        platform = data.get('platform', '').strip().lower()
        token = data.get('token', '').strip()
        
        if platform not in ['discord', 'telegram']:
            return jsonify({'error': 'Plataforma deve ser discord ou telegram'}), 400
            
        if not token:
            return jsonify({'error': 'Token é obrigatório'}), 400
        
        # Verificar se já existe config para esta plataforma
        existing = BotConfig.query.filter_by(platform=platform).first()
        if existing:
            return jsonify({'error': f'Configuração para {platform} já existe'}), 400
        
        config = BotConfig(platform=platform, token=token)
        db.session.add(config)
        db.session.commit()
        
        return jsonify({'message': 'Configuração criada com sucesso', 'config': config.to_dict()}), 201
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': f'Erro interno: {str(e)}'}), 500

@bot_bp.route('/configs/<int:config_id>', methods=['PUT'])
@login_required
def update_bot_config(config_id):
    if not current_user.is_admin:
        return jsonify({'error': 'Acesso negado'}), 403
        
    try:
        config = BotConfig.query.get_or_404(config_id)
        data = request.get_json()
        
        if 'token' in data:
            config.token = data['token'].strip()
            
        if 'is_active' in data:
            config.is_active = bool(data['is_active'])
            
        db.session.commit()
        
        return jsonify({'message': 'Configuração atualizada com sucesso', 'config': config.to_dict()}), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': f'Erro interno: {str(e)}'}), 500

@bot_bp.route('/configs/<int:config_id>', methods=['DELETE'])
@login_required
def delete_bot_config(config_id):
    if not current_user.is_admin:
        return jsonify({'error': 'Acesso negado'}), 403
        
    try:
        config = BotConfig.query.get_or_404(config_id)
        
        # Parar o bot se estiver rodando
        if config.platform in bot_processes:
            stop_bot(config.platform)
            
        db.session.delete(config)
        db.session.commit()
        
        return jsonify({'message': 'Configuração deletada com sucesso'}), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': f'Erro interno: {str(e)}'}), 500

@bot_bp.route('/commands', methods=['GET'])
@login_required
def get_bot_commands():
    commands = BotCommand.query.all()
    return jsonify({'commands': [cmd.to_dict() for cmd in commands]}), 200

@bot_bp.route('/commands', methods=['POST'])
@login_required
def create_bot_command():
    if not current_user.is_admin:
        return jsonify({'error': 'Acesso negado'}), 403
        
    try:
        data = request.get_json()
        
        command_name = data.get('command_name', '').strip()
        command_description = data.get('command_description', '').strip()
        command_code = data.get('command_code', '').strip()
        platform = data.get('platform', '').strip().lower()
        
        if not command_name or not command_code:
            return jsonify({'error': 'Nome e código do comando são obrigatórios'}), 400
            
        if platform not in ['discord', 'telegram', 'both']:
            return jsonify({'error': 'Plataforma deve ser discord, telegram ou both'}), 400
        
        command = BotCommand(
            command_name=command_name,
            command_description=command_description,
            command_code=command_code,
            platform=platform
        )
        
        db.session.add(command)
        db.session.commit()
        
        return jsonify({'message': 'Comando criado com sucesso', 'command': command.to_dict()}), 201
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': f'Erro interno: {str(e)}'}), 500

@bot_bp.route('/commands/<int:command_id>', methods=['PUT'])
@login_required
def update_bot_command(command_id):
    if not current_user.is_admin:
        return jsonify({'error': 'Acesso negado'}), 403
        
    try:
        command = BotCommand.query.get_or_404(command_id)
        data = request.get_json()
        
        if 'command_name' in data:
            command.command_name = data['command_name'].strip()
            
        if 'command_description' in data:
            command.command_description = data['command_description'].strip()
            
        if 'command_code' in data:
            command.command_code = data['command_code'].strip()
            
        if 'platform' in data:
            platform = data['platform'].strip().lower()
            if platform in ['discord', 'telegram', 'both']:
                command.platform = platform
                
        if 'is_active' in data:
            command.is_active = bool(data['is_active'])
            
        db.session.commit()
        
        return jsonify({'message': 'Comando atualizado com sucesso', 'command': command.to_dict()}), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': f'Erro interno: {str(e)}'}), 500

@bot_bp.route('/commands/<int:command_id>', methods=['DELETE'])
@login_required
def delete_bot_command(command_id):
    if not current_user.is_admin:
        return jsonify({'error': 'Acesso negado'}), 403
        
    try:
        command = BotCommand.query.get_or_404(command_id)
        db.session.delete(command)
        db.session.commit()
        
        return jsonify({'message': 'Comando deletado com sucesso'}), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': f'Erro interno: {str(e)}'}), 500

@bot_bp.route('/start/<platform>', methods=['POST'])
@login_required
def start_bot(platform):
    if not current_user.is_admin:
        return jsonify({'error': 'Acesso negado'}), 403
        
    if platform not in ['discord', 'telegram']:
        return jsonify({'error': 'Plataforma inválida'}), 400
        
    if platform in bot_processes and bot_processes[platform].poll() is None:
        return jsonify({'error': f'Bot {platform} já está rodando'}), 400
        
    config = BotConfig.query.filter_by(platform=platform, is_active=True).first()
    if not config:
        return jsonify({'error': f'Configuração para {platform} não encontrada ou inativa'}), 400
        
    try:
        # Caminho para o script do bot
        bot_script = f'/home/ubuntu/discord_telegram_bot_server/backend/bot_server/src/bots/{platform}_bot.py'
        
        if not os.path.exists(bot_script):
            return jsonify({'error': f'Script do bot {platform} não encontrado'}), 404
            
        # Iniciar o bot em um processo separado
        process = subprocess.Popen([
            'python3', bot_script, config.token
        ], cwd='/home/ubuntu/discord_telegram_bot_server/backend/bot_server')
        
        bot_processes[platform] = process
        
        return jsonify({'message': f'Bot {platform} iniciado com sucesso'}), 200
        
    except Exception as e:
        return jsonify({'error': f'Erro ao iniciar bot: {str(e)}'}), 500

@bot_bp.route('/stop/<platform>', methods=['POST'])
@login_required
def stop_bot_route(platform):
    if not current_user.is_admin:
        return jsonify({'error': 'Acesso negado'}), 403
        
    if platform not in ['discord', 'telegram']:
        return jsonify({'error': 'Plataforma inválida'}), 400
        
    try:
        result = stop_bot(platform)
        if result:
            return jsonify({'message': f'Bot {platform} parado com sucesso'}), 200
        else:
            return jsonify({'error': f'Bot {platform} não estava rodando'}), 400
            
    except Exception as e:
        return jsonify({'error': f'Erro ao parar bot: {str(e)}'}), 500

def stop_bot(platform):
    if platform in bot_processes:
        process = bot_processes[platform]
        if process.poll() is None:  # Processo ainda está rodando
            process.terminate()
            try:
                process.wait(timeout=5)
            except subprocess.TimeoutExpired:
                process.kill()
            del bot_processes[platform]
            return True
    return False

@bot_bp.route('/status', methods=['GET'])
@login_required
def get_bot_status():
    status = {}
    for platform in ['discord', 'telegram']:
        if platform in bot_processes:
            process = bot_processes[platform]
            status[platform] = {
                'running': process.poll() is None,
                'pid': process.pid if process.poll() is None else None
            }
        else:
            status[platform] = {'running': False, 'pid': None}
            
    return jsonify({'status': status}), 200

