#!/usr/bin/env python3
"""
Script para popular o banco de dados com comandos de exemplo
"""
import sys
import os

# Adicionar o diretório pai ao path
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from src.models.user import db, BotCommand
from src.bots.example_commands import EXAMPLE_COMMANDS
from src.main import app

def populate_example_commands():
    """Popular o banco com comandos de exemplo"""
    with app.app_context():
        print("Populando comandos de exemplo...")
        
        for cmd_key, cmd_data in EXAMPLE_COMMANDS.items():
            # Verificar se comando já existe
            existing = BotCommand.query.filter_by(command_name=cmd_data['name']).first()
            
            if not existing:
                command = BotCommand(
                    command_name=cmd_data['name'],
                    command_description=cmd_data['description'],
                    command_code=cmd_data['code'],
                    platform=cmd_data['platform']
                )
                
                db.session.add(command)
                print(f"✅ Comando '{cmd_data['name']}' adicionado")
            else:
                print(f"⚠️ Comando '{cmd_data['name']}' já existe")
        
        db.session.commit()
        print("✅ Comandos de exemplo populados com sucesso!")

if __name__ == "__main__":
    populate_example_commands()

