import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  Bot, 
  Users, 
  Settings, 
  Activity, 
  Play, 
  Square, 
  RefreshCw,
  LogOut,
  Shield,
  Code,
  MessageSquare,
  Server
} from 'lucide-react';

const Dashboard = ({ user, onLogout }) => {
  const [botStatus, setBotStatus] = useState({
    discord: { running: false, pid: null },
    telegram: { running: false, pid: null }
  });
  const [stats, setStats] = useState({
    totalUsers: 0,
    totalCommands: 0,
    activeConfigs: 0
  });

  useEffect(() => {
    fetchBotStatus();
    fetchStats();
    // Atualizar status a cada 30 segundos
    const interval = setInterval(() => {
      fetchBotStatus();
      fetchStats();
    }, 30000);

    return () => clearInterval(interval);
  }, []);

  const fetchBotStatus = async () => {
    try {
      const response = await fetch('/api/bot/status', {
        credentials: 'include'
      });
      if (response.ok) {
        const data = await response.json();
        setBotStatus(data.status);
      }
    } catch (error) {
      console.error('Erro ao buscar status dos bots:', error);
    }
  };

  const fetchStats = async () => {
    try {
      const [usersRes, commandsRes, configsRes] = await Promise.all([
        fetch('/api/auth/users', { credentials: 'include' }),
        fetch('/api/bot/commands', { credentials: 'include' }),
        fetch('/api/bot/configs', { credentials: 'include' })
      ]);

      if (usersRes.ok) {
        const usersData = await usersRes.json();
        setStats(prev => ({ ...prev, totalUsers: usersData.users?.length || 0 }));
      }

      if (commandsRes.ok) {
        const commandsData = await commandsRes.json();
        setStats(prev => ({ ...prev, totalCommands: commandsData.commands?.length || 0 }));
      }

      if (configsRes.ok) {
        const configsData = await configsRes.json();
        setStats(prev => ({ 
          ...prev, 
          activeConfigs: configsData.configs?.filter(c => c.is_active).length || 0 
        }));
      }
    } catch (error) {
      console.error('Erro ao buscar estatísticas:', error);
    }
  };

  const handleBotAction = async (platform, action) => {
    try {
      const response = await fetch(`/api/bot/${action}/${platform}`, {
        method: 'POST',
        credentials: 'include'
      });

      if (response.ok) {
        await fetchBotStatus();
      } else {
        const error = await response.json();
        alert(error.error || `Erro ao ${action} bot ${platform}`);
      }
    } catch (error) {
      console.error(`Erro ao ${action} bot:`, error);
      alert(`Erro ao ${action} bot ${platform}`);
    }
  };

  const StatCard = ({ title, value, icon: Icon, description, color = "purple" }) => (
    <Card className="hover-lift border-purple-500/20">
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <CardTitle className="text-sm font-medium text-gray-300">{title}</CardTitle>
        <Icon className={`h-4 w-4 text-${color}-400`} />
      </CardHeader>
      <CardContent>
        <div className="text-2xl font-bold text-white">{value}</div>
        <p className="text-xs text-gray-400 mt-1">{description}</p>
      </CardContent>
    </Card>
  );

  const BotCard = ({ platform, status, onStart, onStop }) => (
    <Card className="hover-lift border-purple-500/20">
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-2 text-white">
            <Bot className="h-5 w-5 text-purple-400" />
            Bot {platform.charAt(0).toUpperCase() + platform.slice(1)}
          </CardTitle>
          <Badge 
            variant={status.running ? "default" : "secondary"}
            className={status.running ? "bg-green-600 hover:bg-green-700" : "bg-gray-600"}
          >
            {status.running ? 'Online' : 'Offline'}
          </Badge>
        </div>
        <CardDescription className="text-gray-400">
          {status.running 
            ? `PID: ${status.pid}` 
            : 'Bot não está rodando'
          }
        </CardDescription>
      </CardHeader>
      <CardContent className="flex gap-2">
        {status.running ? (
          <Button 
            onClick={onStop} 
            variant="destructive" 
            size="sm"
            className="flex items-center gap-2"
          >
            <Square className="h-4 w-4" />
            Parar
          </Button>
        ) : (
          <Button 
            onClick={onStart} 
            className="gradient-purple hover:opacity-90 flex items-center gap-2"
            size="sm"
          >
            <Play className="h-4 w-4" />
            Iniciar
          </Button>
        )}
        <Button 
          onClick={() => fetchBotStatus()} 
          variant="outline" 
          size="sm"
          className="border-purple-500/50 text-purple-400 hover:bg-purple-500/10"
        >
          <RefreshCw className="h-4 w-4" />
        </Button>
      </CardContent>
    </Card>
  );

  return (
    <div className="min-h-screen gradient-dark">
      {/* Header */}
      <header className="border-b border-purple-500/20 bg-black/50 backdrop-blur-sm">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-purple-600/20 glow-animation">
                <Bot className="h-6 w-6 text-purple-400" />
              </div>
              <div>
                <h1 className="text-xl font-bold text-white">Bot Control Panel</h1>
                <p className="text-sm text-gray-400">Painel de Controle de Bots</p>
              </div>
            </div>
            
            <div className="flex items-center gap-4">
              <div className="flex items-center gap-2 text-sm text-gray-300">
                <Shield className="h-4 w-4 text-purple-400" />
                <span>{user.username}</span>
                {user.is_admin && (
                  <Badge className="bg-purple-600 hover:bg-purple-700">Admin</Badge>
                )}
              </div>
              <Button 
                onClick={onLogout} 
                variant="outline"
                size="sm"
                className="border-red-500/50 text-red-400 hover:bg-red-500/10"
              >
                <LogOut className="h-4 w-4 mr-2" />
                Sair
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8">
        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <StatCard
            title="Usuários Totais"
            value={stats.totalUsers}
            icon={Users}
            description="Usuários registrados no sistema"
          />
          <StatCard
            title="Comandos Ativos"
            value={stats.totalCommands}
            icon={Code}
            description="Comandos disponíveis nos bots"
          />
          <StatCard
            title="Configurações Ativas"
            value={stats.activeConfigs}
            icon={Settings}
            description="Bots configurados e ativos"
          />
        </div>

        {/* Bot Status */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
          <BotCard
            platform="discord"
            status={botStatus.discord}
            onStart={() => handleBotAction('discord', 'start')}
            onStop={() => handleBotAction('discord', 'stop')}
          />
          <BotCard
            platform="telegram"
            status={botStatus.telegram}
            onStart={() => handleBotAction('telegram', 'start')}
            onStop={() => handleBotAction('telegram', 'stop')}
          />
        </div>

        {/* Tabs for different sections */}
        <Tabs defaultValue="overview" className="space-y-6">
          <TabsList className="grid w-full grid-cols-4 bg-gray-800/50 border border-purple-500/20">
            <TabsTrigger value="overview" className="data-[state=active]:bg-purple-600">
              <Activity className="h-4 w-4 mr-2" />
              Visão Geral
            </TabsTrigger>
            <TabsTrigger value="bots" className="data-[state=active]:bg-purple-600">
              <Bot className="h-4 w-4 mr-2" />
              Bots
            </TabsTrigger>
            <TabsTrigger value="users" className="data-[state=active]:bg-purple-600">
              <Users className="h-4 w-4 mr-2" />
              Usuários
            </TabsTrigger>
            <TabsTrigger value="settings" className="data-[state=active]:bg-purple-600">
              <Settings className="h-4 w-4 mr-2" />
              Configurações
            </TabsTrigger>
          </TabsList>

          <TabsContent value="overview">
            <Card className="border-purple-500/20">
              <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                  <Activity className="h-5 w-5 text-purple-400" />
                  Atividade Recente
                </CardTitle>
                <CardDescription className="text-gray-400">
                  Últimas atividades do sistema
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center gap-3 p-3 rounded-lg bg-gray-800/30">
                    <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                    <span className="text-gray-300">Sistema iniciado com sucesso</span>
                    <span className="text-xs text-gray-500 ml-auto">Agora</span>
                  </div>
                  <div className="flex items-center gap-3 p-3 rounded-lg bg-gray-800/30">
                    <div className="w-2 h-2 bg-purple-500 rounded-full"></div>
                    <span className="text-gray-300">Comandos de exemplo carregados</span>
                    <span className="text-xs text-gray-500 ml-auto">Agora</span>
                  </div>
                  <div className="flex items-center gap-3 p-3 rounded-lg bg-gray-800/30">
                    <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                    <span className="text-gray-300">Usuário admin criado</span>
                    <span className="text-xs text-gray-500 ml-auto">Agora</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="bots">
            <Card className="border-purple-500/20">
              <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                  <MessageSquare className="h-5 w-5 text-purple-400" />
                  Gerenciamento de Bots
                </CardTitle>
                <CardDescription className="text-gray-400">
                  Configure e gerencie seus bots Discord e Telegram
                </CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-gray-400">
                  Use as abas "Usuários" e "Configurações" para gerenciar bots em detalhes.
                  Os controles básicos estão disponíveis nos cards acima.
                </p>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="users">
            <Card className="border-purple-500/20">
              <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                  <Users className="h-5 w-5 text-purple-400" />
                  Gerenciamento de Usuários
                </CardTitle>
                <CardDescription className="text-gray-400">
                  Gerencie usuários do sistema
                </CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-gray-400">
                  Funcionalidade de gerenciamento de usuários será implementada aqui.
                  Atualmente você pode ver o total de usuários nas estatísticas acima.
                </p>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="settings">
            <Card className="border-purple-500/20">
              <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                  <Server className="h-5 w-5 text-purple-400" />
                  Configurações do Sistema
                </CardTitle>
                <CardDescription className="text-gray-400">
                  Configure tokens e parâmetros dos bots
                </CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-gray-400">
                  Funcionalidade de configurações será implementada aqui.
                  Use a API diretamente para configurar tokens dos bots por enquanto.
                </p>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </main>
    </div>
  );
};

export default Dashboard;

